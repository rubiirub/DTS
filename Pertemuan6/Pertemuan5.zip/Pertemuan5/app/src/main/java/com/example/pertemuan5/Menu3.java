package com.example.pertemuan5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Scanner;

public class Menu3 extends AppCompatActivity {
    EditText txt_nama;
    TextView lbl_hasil;
    Integer nama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu3);

        txt_nama = findViewById(R.id.txt_nama);
        lbl_hasil = findViewById(R.id.lbl_hasil);
    }
    public void Tampil_hasil(View v){
        lbl_hasil.setText("Nama Anda adalah: "+txt_nama.getText());
    }
}
