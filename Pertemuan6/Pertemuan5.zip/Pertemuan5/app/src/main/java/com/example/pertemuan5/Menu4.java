package com.example.pertemuan5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Scanner;


public class Menu4 extends AppCompatActivity {
    EditText txt_angka;
    TextView lbl_hasil;
    int x, y, angka;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu4);

        txt_angka = findViewById(R.id.txt_angka);
        lbl_hasil = findViewById(R.id.lbl_hasil);
        }


    public void Tampil_akar (View v) {
        int angka = Integer.parseInt(txt_angka.getText().toString());
        x= 1;
        y= x*x;

        while (y!=angka){
            x=x+1;
            y=x*x;
        }

        lbl_hasil.setText("Akar : " + x);
    }


}
