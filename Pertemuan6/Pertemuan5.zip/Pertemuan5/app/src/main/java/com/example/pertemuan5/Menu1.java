package com.example.pertemuan5;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu1 extends AppCompatActivity {
    //deklarasi object java
    Button BtnAhsiap, BtnKuning;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        //hubungkan object java dengan ID XML
        BtnAhsiap = findViewById(R.id.btn_tampil);
        BtnKuning = findViewById(R.id.btn2);

    }
    //code merubah warna
    public void Rubah_Warna(View v) {
        BtnAhsiap.setBackgroundColor(Color.BLUE);


    }
    public void Rubah_Kuning(View v){
        BtnKuning.setBackgroundColor(Color.YELLOW);
    }


}
